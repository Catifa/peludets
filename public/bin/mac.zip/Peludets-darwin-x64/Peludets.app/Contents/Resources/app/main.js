const { app, BrowserWindow } = require("electron");

function createWindow() {
  const win = new BrowserWindow({
    icon: "logo.png",
    width: 1000,
    height: 600,
    show:false,
    webPreferences: {
      nodeIntegration: true,
    },
  });

  splash = new BrowserWindow({
    width:1100,
    height: 700,
    transparent: true,
    frame: false,
    alwaysOnTop: true,
  });
  splash.loadFile("index.html");

  win.loadURL("http://www.peludets.cat");
  win.removeMenu();
  // if main window is ready to show, then destroy the splash window and show up the main window
  win.once("ready-to-show", () => {
    splash.destroy();
    win.show();
  });
}

app.whenReady().then(createWindow);

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    app.quit();
  }
});

app.on("activate", () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});
